#include <assert.h>

#include "heap.h"

int pop(struct heap *heap)
{
    assert(heap->size > 0);
    int res = heap->array[0];
    heap->size -= 1;
    heap->array += 1;
    return res;
}
