#include <stdio.h>

#include "heap.h"

void print_array(int *array, size_t len, size_t pos)
{
    if (pos < len)
    {
        int val = *(array + pos);
        while (val > 9)
        {
            char c = '0' + (val / 10);
            putchar(c);
            val /= 10;
        }
        char c = '0' + val;
        putchar(c);
        putchar(' ');
        print_array(array, len, (2 * pos) + 1);
        print_array(array, len, (2 * pos) + 2);
    }
}

void print_heap(const struct heap *heap)
{
    print_array(heap->array, heap->size, 0);
    putchar('\n');
}
