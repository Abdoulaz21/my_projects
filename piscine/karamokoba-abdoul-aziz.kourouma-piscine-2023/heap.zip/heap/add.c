#include <stdlib.h>

#include "heap.h"

void add(struct heap *heap, int val)
{
    if (heap->size == heap->capacity)
    {
        heap = realloc(heap, sizeof(int) + sizeof(heap));
        heap->capacity += 1;
        heap->array = realloc(heap->array, sizeof(int) + sizeof(heap->array));
    }
    size_t pos = heap->size;
    heap->array[pos] = val;
    heap->size += 1;
}
