#include <stdio.h>

#include "heap.h"

int main(void)
{
    struct heap *myheap = create_heap();
    for (int i = 1;i < 16;i++)
    {
        add(myheap, i);
    }
    //print_heap(myheap);
    printf("first element: %d\n", pop(myheap));
    //print_heap(myheap);
    delete_heap(myheap);
    return 0;
}
